## Infrastructure as Code

This is my terraform files. It creates working infrastructure along with all components out of the box!
